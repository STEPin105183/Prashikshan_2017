import cv2
import numpy as np
# comment here
def detectCellVal(img_rgb,grid_map):
    #code here
    digit=np.zeros((12,96,96),dtype=np.uint8)
    temp=np.zeros((100,100),dtype=np.uint8)
    demo =cv2.cvtColor(img_rgb,cv2.COLOR_RGB2GRAY)
    for a in range(10):
        path="digits\\"+str(a)+".jpg"
        temp=cv2.imread(path,cv2.IMREAD_GRAYSCALE)
        digit[a]=temp[2:98,2:98]
    temp=cv2.imread("digits\minus.jpg",cv2.IMREAD_GRAYSCALE)
    digit[10]=temp[2:98,2:98]
    temp=cv2.imread("digits\plus.jpg",cv2.IMREAD_GRAYSCALE)
    digit[11]=temp[2:98,2:98]
    def mse(imageA,imageB):
        i=np.sum((imageA.astype("float")-imageB.astype("float"))**2)
        i/=float(imageA.shape[0]**2)
        return i
    for a in range(6):
        for b in range(6):
            temp=demo[((a*100)+2):((a*100)+98),((b*100)+2):((b*100)+98)]
            for c in range(1,12):
                if (mse(digit[c],temp)<10):
                    grid_map[i][j]=c
                    if (c==11):
                        grid_map[i][j]='-'
                    if (c==12):
                        grid_map[i][j]='+'
    s=0
    for a in range(6):
        s+=grid_map[a][0]
        for b in range (2,6,2):
            if ((grid_map[a][b-1])=='+'):
                s=s+grid_map[a][b]
            if ((work_space[a][b-1])=='-'):
                s=s-grid_map[a][b] 
    
    return grid_map
